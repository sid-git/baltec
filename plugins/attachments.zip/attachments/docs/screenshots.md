This is a WordPress plugin. [Official download available on WordPress.org](http://wordpress.org/extend/plugins/attachments/).

## [Docs TOC](TOC.md) / Screenshots

##### An Attachments meta box sitting below the content editor
![An Attachments meta box sitting below the content editor](http://mondaybynoon.com/images/attachments/screenshot-1.png)

##### Direct integration with WordPress 3.5+ Media
![Direct integration with WordPress 3.5+ Media](http://mondaybynoon.com/images/attachments/screenshot-2.png)

##### Attach multiple files at once
![Attach multiple files at once](http://mondaybynoon.com/images/attachments/screenshot-3.png)

##### Custom fields for each Attachment
![Custom fields for each Attachment](http://mondaybynoon.com/images/attachments/screenshot-4.png)

##### Drag and drop to sort
![Drag and drop to sort](http://mondaybynoon.com/images/attachments/screenshot-5.png)

-----

#### Next: [Frequently Asked Questions](faq.md)