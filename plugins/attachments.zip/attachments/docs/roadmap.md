This is a WordPress plugin. [Official download available on WordPress.org](http://wordpress.org/extend/plugins/attachments/).

## [Docs TOC](TOC.md) / Roadmap

Planned feature additions include:

* Additional field type: checkbox
* Additional field type: radio
* User-defined custom field types